create function "_pg_numeric_scale"(typid oid, typmod integer) returns integer
    immutable
    strict
    language sql
as
$$
SELECT
  CASE WHEN $1 IN (21, 23, 20) THEN 0
       WHEN $1 IN (1700) THEN
            CASE WHEN $2 = -1
                 THEN null
                 ELSE ($2 - 4) & 65535
                 END
       ELSE null
  END
$$;

alter function "_pg_numeric_scale"(oid, integer) owner to postgres;

